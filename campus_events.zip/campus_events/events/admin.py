from django.contrib import admin
from django.contrib.auth import get_user_model
from .models import Event, Registration, Attendance, Feedback

User = get_user_model()

# -----------------------
# Custom User Admin
# -----------------------
@admin.register(User)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('email', 'is_staff', 'is_active')
    search_fields = ('email',)
    list_filter = ('is_staff', 'is_active')


# -----------------------
# Event Admin
# -----------------------
@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('title', 'event_type', 'date')
    list_filter = ('event_type', 'date')
    search_fields = ('title', 'description')


# -----------------------
# Registration Admin
# -----------------------
@admin.register(Registration)
class RegistrationAdmin(admin.ModelAdmin):
    list_display = ('student', 'event', 'registered_at')
    list_filter = ('event',)
    search_fields = ('student__email', 'event__title')


# -----------------------
# Attendance Admin
# -----------------------
@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ('student', 'event', 'attended_at')  # make sure your model has `attended_at`
    list_filter = ('event',)
    search_fields = ('student__email', 'event__title')


# -----------------------
# Feedback Admin
# -----------------------
@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('student', 'event', 'rating', 'submitted_at')  # make sure your model has `submitted_at`
    list_filter = ('event',)
    search_fields = ('student__email', 'event__title')
