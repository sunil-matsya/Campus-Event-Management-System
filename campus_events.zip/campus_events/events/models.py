from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models
from django.conf import settings

# -----------------------
# Custom User
# -----------------------
class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("Users must have an email address")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        return self.create_user(email, password, **extra_fields)


class CustomUser(AbstractUser):
    username = None  # Remove username
    email = models.EmailField(unique=True)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    objects = CustomUserManager()

    def __str__(self):
        return self.email


# -----------------------
# Event Model
# -----------------------
class Event(models.Model):
    EVENT_TYPES = [
        ("workshop", "Workshop"),
        ("hackathon", "Hackathon"),
        ("seminar", "Seminar"),
        ("fest", "Fest"),
        ("tech_talk", "Tech Talk"),
    ]

    title = models.CharField(max_length=200)
    description = models.TextField()
    event_type = models.CharField(max_length=50, choices=EVENT_TYPES)
    date = models.DateField()
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="events"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.event_type})"


# -----------------------
# Registration Model
# -----------------------
class Registration(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="registrations"
    )
    event = models.ForeignKey(
        Event, on_delete=models.CASCADE, related_name="registrations"
    )
    registered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("student", "event")  # prevent duplicate registrations

    def __str__(self):
        return f"{self.student.email} -> {self.event.title}"


# -----------------------
# Attendance Model
# -----------------------
class Attendance(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="attendances"
    )
    event = models.ForeignKey(
        Event, on_delete=models.CASCADE, related_name="attendances"
    )
    attended_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("student", "event")  # one attendance per student per event

    def __str__(self):
        return f"{self.student.email} attended {self.event.title}"


# -----------------------
# Feedback Model
# -----------------------
class Feedback(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="feedbacks"
    )
    event = models.ForeignKey(
        Event, on_delete=models.CASCADE, related_name="feedbacks"
    )
    rating = models.IntegerField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("student", "event")

    def __str__(self):
        return f"{self.student.email} rated {self.event.title}: {self.rating}"

