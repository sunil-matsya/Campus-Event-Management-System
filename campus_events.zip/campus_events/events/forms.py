# events/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, Event

# -----------------------
# Student / User Signup Form
# -----------------------
class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={
        'class': 'form-control', 'placeholder': 'Email'
    }))
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'form-control', 'placeholder': 'Password'
    }))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={
        'class': 'form-control', 'placeholder': 'Confirm Password'
    }))

    class Meta:
        model = CustomUser
        fields = ("email", "password1", "password2")

# -----------------------
# Event Creation Form (Staff)
# -----------------------
class EventForm(forms.ModelForm):
    date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}))

    class Meta:
        model = Event
        fields = ["title", "description", "event_type", "date"]
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Event Title'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Event Description'}),
            'event_type': forms.Select(attrs={'class': 'form-control'}),
        }
