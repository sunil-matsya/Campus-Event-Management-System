from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.db.models import Count
from django.http import HttpResponse
import csv

from .models import Event, Registration, Attendance, Feedback
from .forms import EventForm

User = get_user_model()

# ---- Role check ----
def is_staff(user):
    return user.is_staff

# ---- Authentication Views ----
def signup_view(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        if not email or not password:
            messages.error(request, "Both email and password are required")
            return redirect("signup")

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered")
        else:
            user = User.objects.create_user(email=email, password=password)
            login(request, user)
            if user.is_staff:
                return redirect("staff_dashboard")
            return redirect("student_dashboard")
    return render(request, "signup.html")

def login_view(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")
        user = authenticate(request, email=email, password=password)
        if user:
            login(request, user)
            if user.is_staff:
                return redirect("staff_dashboard")
            return redirect("student_dashboard")
        else:
            messages.error(request, "Invalid credentials")
    return render(request, "login.html")

def logout_view(request):
    logout(request)
    return redirect("login")

# ---- Staff Views ----
@user_passes_test(is_staff)
def staff_dashboard(request):
    events = Event.objects.all().order_by("-date")
    return render(request, "staff_dashboard.html", {"events": events})

@user_passes_test(is_staff)
def create_event(request):
    if request.method == "POST":
        form = EventForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Event created successfully")
            return redirect("staff_dashboard")
    else:
        form = EventForm()
    return render(request, "create_event.html", {"form": form})

# ---- Student Views ----
@login_required
def student_dashboard(request):
    events = Event.objects.all().order_by("-date")
    registrations = Registration.objects.filter(student=request.user).values_list('event_id', flat=True)
    attendance = Attendance.objects.filter(student=request.user).values_list('event_id', flat=True)
    feedback = {f.event_id: f.rating for f in Feedback.objects.filter(student=request.user)}
    return render(request, "student_dashboard.html", {
        "events": events,
        "registrations": registrations,
        "attendance": attendance,
        "feedback": feedback,
    })

@login_required
def register_event(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    if not Registration.objects.filter(student=request.user, event=event).exists():
        Registration.objects.create(student=request.user, event=event)
        messages.success(request, "Registered successfully")
    return redirect("student_dashboard")

@login_required
def mark_attendance(request, event_id):
    event = get_object_or_404(Event, id=event_id)
    if not Attendance.objects.filter(student=request.user, event=event).exists():
        Attendance.objects.create(student=request.user, event=event)
        messages.success(request, "Attendance marked")
    return redirect("student_dashboard")

@login_required
def submit_feedback(request, event_id):
    if request.method == "POST":
        rating = int(request.POST.get("rating"))
        event = get_object_or_404(Event, id=event_id)
        Feedback.objects.update_or_create(student=request.user, event=event, defaults={"rating": rating})
        messages.success(request, "Feedback submitted")
    return redirect("student_dashboard")

# ---- Reports (staff) ----
@user_passes_test(is_staff)
def event_popularity_report(request):
    events = Event.objects.annotate(total_registrations=Count('registrations')).order_by('-total_registrations')
    return render(request, "reports/event_popularity.html", {"events": events})

@user_passes_test(is_staff)
def student_participation_report(request):
    students = User.objects.annotate(total_attendance=Count('attendances')).order_by('-total_attendance')
    return render(request, "reports/student_participation.html", {"students": students})

@user_passes_test(is_staff)
def top_active_students(request):
    top_students = User.objects.annotate(total_attendance=Count('attendances')).order_by('-total_attendance')[:3]
    return render(request, "reports/top_active_students.html", {"students": top_students})

# ---- CSV downloads ----
@user_passes_test(is_staff)
def download_event_popularity_csv(request):
    events = Event.objects.annotate(total_registrations=Count('registrations')).order_by('-total_registrations')
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="event_popularity.csv"'
    writer = csv.writer(response)
    writer.writerow(['Title', 'Type', 'Date', 'Registrations'])
    for e in events:
        writer.writerow([e.title, e.event_type, e.date, e.total_registrations])
    return response

@user_passes_test(is_staff)
def download_student_participation_csv(request):
    students = User.objects.annotate(total_attendance=Count('attendances')).order_by('-total_attendance')
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="student_participation.csv"'
    writer = csv.writer(response)
    writer.writerow(['Email', 'Total Attendance'])
    for s in students:
        writer.writerow([s.email, s.total_attendance])
    return response

@user_passes_test(is_staff)
def download_top_active_students_csv(request):
    top_students = User.objects.annotate(total_attendance=Count('attendances')).order_by('-total_attendance')[:3]
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="top_active_students.csv"'
    writer = csv.writer(response)
    writer.writerow(['Email', 'Total Attendance'])
    for s in top_students:
        writer.writerow([s.email, s.total_attendance])
    return response
