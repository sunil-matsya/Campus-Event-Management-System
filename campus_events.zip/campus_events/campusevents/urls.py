from django.contrib import admin
from django.urls import path
from django.shortcuts import redirect
from events import views

urlpatterns = [
    path('admin/', admin.site.urls),

    # Authentication
    path('', lambda request: redirect('login')),  # redirect root to login
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # Student
    path('student/dashboard/', views.student_dashboard, name='student_dashboard'),
    path('student/register/<int:event_id>/', views.register_event, name='register_event'),
    path('student/attendance/<int:event_id>/', views.mark_attendance, name='mark_attendance'),
    path('student/feedback/<int:event_id>/', views.submit_feedback, name='submit_feedback'),

    # Staff
    path('staff/dashboard/', views.staff_dashboard, name='staff_dashboard'),
    path('staff/create-event/', views.create_event, name='create_event'),

    # Reports (staff)
    path('staff/reports/events/', views.event_popularity_report, name='event_popularity_report'),
    path('staff/reports/students/', views.student_participation_report, name='student_participation_report'),
    path('staff/reports/top-students/', views.top_active_students, name='top_active_students'),

    # Download CSV
    path('staff/reports/events/download/', views.download_event_popularity_csv, name='download_event_csv'),
    path('staff/reports/students/download/', views.download_student_participation_csv, name='download_student_csv'),
    path('staff/reports/top-students/download/', views.download_top_active_students_csv, name='download_top_students_csv'),
]
